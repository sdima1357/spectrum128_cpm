/**
  ******************************************************************************
  * @file    ili9341.c
  * @author  MCD Application Team
  * @version V1.0.2
  * @date    02-December-2014
  * @brief   This file includes the LCD driver for ILI9341 LCD.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2014 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "ili9341.h"
#include "main.h"
void    Delay(int num)
{
	//HAL_Delay(num);
	uint32_t start = HAL_GetTick()+num;
	while((uint32_t)(HAL_GetTick()-start)>0x80000)
	{
		kscan0();
	}
}

void LCD_Delay(uint32_t d)
{
	Delay(d);
}

#define LCD_REG      (*((volatile unsigned short *) 0x60000000)) 
// A18
#define LCD_RAM      (*((volatile unsigned short *) (0x60000000+(1<<(18+1))) )) 
// A16

inline  void FMC_BANK1_WriteData(uint16_t Data) 
{
  /* Write 16-bit Reg */
	//~ FMC_BANK1->RAM = Data;
  LCD_RAM = Data;
}

inline void FMC_BANK1_WriteReg(uint8_t Reg) 
{
  /* Write 16-bit Index, then write register */
	//~ FMC_BANK1->REG = Reg;
  LCD_REG = Reg;
}


uint16_t LCD_RD_DATA(void)
{
	return LCD_RAM;
}

void LCD_WriteReg(uint16_t LCD_Reg, uint16_t LCD_RegValue)
{
	LCD_REG = LCD_Reg;		//Ð´ÈëÒªÐ´µÄ¼Ä´æÆ÷ÐòºÅ
	LCD_RAM = LCD_RegValue;//Ð´ÈëÊý¾Ý
}

void LCD_ReadReg(uint16_t LCD_Reg,uint8_t *Rval,int n)
{
	LCD_REG = LCD_Reg;
	while(n--)
	{
		*(Rval++) = LCD_RD_DATA();
		Delay(1);
	}
}

uint16_t LCD_Read_ID4(void)
{
	uint8_t val[4] = {0};
	LCD_ReadReg(0xD300,val,4);
	printf("%x %x %x %x \n ",val[0],val[1],val[2],val[3]);
	return (val[2]<<8)|val[3];
}


/**
  * @brief  Reads register value.
  * @retval Read value
  */
inline uint16_t FMC_BANK1_ReadData(void) 
{
	//~ return FMC_BANK1->RAM;
	//~ return FWREAD();
  return LCD_RAM;
}

/**
  * @brief  Writes data on LCD data register.
  * @param  Data: Data to be written
  */
void  LCD_IO_WriteData(uint16_t Data)
{
  /* Write 16-bit Reg */
  FMC_BANK1_WriteData(Data);
}

/**
  * @brief  Writes multiple data on LCD data register.
  * @param  pData Pointer on the register value
  * @param  Size Size of byte to transmit to the register
  * @retval None
  */
inline void LCD_IO_WriteMultipleData(uint8_t *pData, uint32_t Size)
{
  uint32_t counter;
  uint16_t *ptr = (uint16_t *) pData;
  
  for (counter = 0; counter < Size; counter+=2)
  {  
    /* Write 16-bit Reg */
    FMC_BANK1_WriteData(*ptr);
    ptr++;
  }
}

/*****************************************************************************
 * @name       :void LCD_WR_REG(u16 data)
 * @date       :2018-08-09
 * @function   :Write an 16-bit command to the LCD screen
 * @parameters :data:Command value to be written
 * @retvalue   :None
******************************************************************************/
void LCD_WR_REG(uint16_t data)
{
	LCD_REG = data;
}

/*****************************************************************************
 * @name       :void LCD_WR_DATA(u16 data)
 * @date       :2018-08-09
 * @function   :Write an 16-bit data to the LCD screen
 * @parameters :data:data value to be written
 * @retvalue   :None
******************************************************************************/
void LCD_WR_DATA(uint16_t data)
{
	LCD_RAM=data;
}


/**
  * @brief  Writes register on LCD register.
  * @param  Reg: Register to be written
  */
void LCD_IO_WriteReg(uint8_t Reg)
{
  /* Write 16-bit Index, then Write Reg */
  FMC_BANK1_WriteReg(Reg);
}

/**
  * @brief  Reads data from LCD data register.
  * @param  Reg: Register to be read
  * @retval Read data.
  */
inline uint16_t LCD_IO_ReadData(uint16_t Reg)
{
  FMC_BANK1_WriteReg(Reg);
  
  /* Read 16-bit Reg */  
  return FMC_BANK1_ReadData();
}


uint16_t F_LCD_IO_ReadData(uint16_t Reg)
{
	return LCD_IO_ReadData(Reg);
}
uint16_t F_FMC_BANK1_ReadData()
{
	return LCD_RAM;
}

#define TFT_REG_COL         0x2A
#define TFT_REG_PAGE        0x2B
#define TFT_REG_MEM_WRITE   0x2C
#define TFT_REG_TE_OFF      0x34
#define TFT_REG_TE_ON       0x35
#define TFT_REG_GAMMA_1     0xe0
#define TFT_REG_GAMMA_2     0xe1

      void initTft();
     void tftReset();
     void sendRegister(unsigned int reg);
     void sendCommand(unsigned int data);
     void sendData(unsigned int data);
     void pushDataReg(unsigned int data);
     void pushDataRam(unsigned int data);
     void enterSleep();
     void exitSleep();
     void setOrientation(unsigned int HV);
     void setXY(uint16_t poX, uint16_t poY);
    void setCol(uint16_t startX, uint16_t endX);
    void setPage(uint16_t startY, uint16_t endY);
    void fillRectangle(uint16_t poX, uint16_t poY,
                       uint16_t width, uint16_t length,
                       uint16_t color);
    void drawHorizontalLine(uint16_t poX, uint16_t poY, uint16_t length,
                            uint16_t color);
    void setWindow(uint16_t startX, uint16_t startY, uint16_t endX, uint16_t endY);
    void setBacklightON();
    void setBacklightOff();

void ili9341_WriteReg(uint8_t LCD_Reg)
{
  LCD_IO_WriteReg(LCD_Reg);
}
/*
void    Delay(int num)
{
	HAL_Delay(num);
}
*/
/**
  * @brief  Writes data to the selected LCD register.
  * @param  LCD_Reg: address of the selected register.
  * @retval None
  */
void setBK_imp(int perc);

int iBacklightPercent = 50;
void setBacklight(int percent)
{
	if(percent>100)percent = 100;
	if(percent<0)percent = 0;
	iBacklightPercent = percent;
	setBK_imp(iBacklightPercent);
}
int getBacklight()
{
	return iBacklightPercent;
}

void setBacklightON()
{

	setBK_imp(iBacklightPercent);

	//HAL_GPIO_WritePin(LCD_BL_GPIO_Port,LCD_BL_Pin,GPIO_PIN_SET);
  //~ TIM4->CCR1 = 333;
}

void setBacklightOff()
{
	setBK_imp(0);
  //~ TIM4->CCR1 = 0;
	//HAL_GPIO_WritePin(LCD_BL_GPIO_Port,LCD_BL_Pin,GPIO_PIN_RESET);
}

#ifdef ILI9341
int16_t ttab[16][2][2];
#else
int16_t ttab[16][4][4];
#endif
void make_ttab()
{
#ifdef ILI9341
	for(int k=0;k<16;k++)
	{
		ttab[k][0][0] = (k >>3)&1;
		ttab[k][0][1] = (k >>2)&1;
		ttab[k][1][0] = (k >>1)&1;
		ttab[k][1][1] = (k >>0)&1;
	}
#else
	for(int k=0;k<16;k++)
	{
		ttab[k][0][0] = (k >>3)&1;
		ttab[k][0][1] = (k >>3)&1;
		ttab[k][1][0] = (k >>3)&1;
		ttab[k][1][1] = (k >>3)&1;

		ttab[k][0][2] = (k >>2)&1;
		ttab[k][0][3] = (k >>2)&1;
		ttab[k][1][2] = (k >>2)&1;
		ttab[k][1][3] = (k >>2)&1;

		ttab[k][2][0] = (k >>1)&1;
		ttab[k][2][1] = (k >>1)&1;
		ttab[k][3][0] = (k >>1)&1;
		ttab[k][3][1] = (k >>1)&1;

		ttab[k][2][2] = (k >>0)&1;
		ttab[k][2][3] = (k >>0)&1;
		ttab[k][3][2] = (k >>0)&1;
		ttab[k][3][3] = (k >>0)&1;
	}
#endif
}


void ili9341_DisplayOn(void)
{
  /* Display On */
  setBacklight(100);
  ili9341_WriteReg(LCD_DISPLAY_ON);
}

/**
  * @brief  Disables the Display.
  * @param  None
  * @retval None
  */
void ili9341_DisplayOff(void)
{
  /* Display Off */
  setBacklight(0);
  ili9341_WriteReg(LCD_DISPLAY_OFF);
}

void ili9341_WriteData(uint16_t RegValue)
{
  LCD_IO_WriteData(RegValue);
}
    
void ili9341_Inita(void)
{
	initTft();
	make_ttab();
	//HAL_GPIO_WritePin(LCD_BL_GPIO_Port,LCD_BL_Pin,GPIO_PIN_SET);
}
    void initTft()
    {
  tftReset();

  sendCommand(0x01);
  sendCommand(0x28);
  
  Delay(5);
  
  sendCommand(0xcf);
  sendRegister(0x0000);
  sendRegister(0x0083);
  sendRegister(0x0030);

  sendCommand(0xed);
  sendRegister(0x0064);
  sendRegister(0x0003);
  sendRegister(0x0012);
  sendRegister(0x0081);

  sendCommand(0xe8);
  sendRegister(0x0085);
  sendRegister(0x0001);
  sendRegister(0x0079);

  sendCommand(0xcb);
  sendRegister(0x0039);
  sendRegister(0x002c);
  sendRegister(0x0000);
  sendRegister(0x0034);
  sendRegister(0x0002);

  sendCommand(0xf7);
  sendRegister(0x0020);

  sendCommand(0xea);
  sendRegister(0x0000);
  sendRegister(0x0000);

  sendCommand(0xc0);
  sendRegister(0x0026);

  sendCommand(0xc1);
  sendRegister(0x0011);

  sendCommand(0xc5);
  sendRegister(0x0035);
  sendRegister(0x003e);

  sendCommand(0xc7);
  sendRegister(0x00be);

  sendCommand(0x36);
  sendRegister(0x0048);//48

  sendCommand(0x3a);
  sendRegister(0x0055);

  sendCommand(0xb1);
  sendRegister(0x0000);
  sendRegister(0x0010); // default 0x1B

  sendCommand(0xF2);
  sendRegister(0x0008);

  sendCommand(0x26);
  sendRegister(0x0001);

  sendCommand(TFT_REG_GAMMA_1);
  sendRegister(0x001f);
  sendRegister(0x001a);
  sendRegister(0x0018);
  sendRegister(0x000a);
  sendRegister(0x000f);
  sendRegister(0x0006);
  sendRegister(0x0045);
  sendRegister(0x0087);
  sendRegister(0x0032);
  sendRegister(0x000a);
  sendRegister(0x0007);
  sendRegister(0x0002);
  sendRegister(0x0007);
  sendRegister(0x0005);
  sendRegister(0x0000);

  sendCommand(TFT_REG_GAMMA_1);
  sendRegister(0x0000);
  sendRegister(0x0025);
  sendRegister(0x0027);
  sendRegister(0x0005);
  sendRegister(0x0010);
  sendRegister(0x0009);
  sendRegister(0x003a);
  sendRegister(0x0078);
  sendRegister(0x004d);
  sendRegister(0x0005);
  sendRegister(0x0018);
  sendRegister(0x000d);
  sendRegister(0x0038);
  sendRegister(0x003a);
  sendRegister(0x001f);

  sendCommand(TFT_REG_COL);
  sendRegister(0x0000);
  sendRegister(0x0000);
  sendRegister(0x0000);
  sendRegister(0x00ef);

  sendCommand(TFT_REG_PAGE);
  sendRegister(0x0000);
  sendRegister(0x0000);
  sendRegister(0x0001);
  sendRegister(0x003f);

  sendCommand(TFT_REG_TE_OFF);
  sendRegister(0x0000);

  sendCommand(0xb7);
  sendRegister(0x0007);

  sendCommand(0xb6);
  sendRegister(0x000a);
  sendRegister(0x0082);
  sendRegister(0x0027);
  sendRegister(0x0000);

  sendCommand(0x11);

  Delay(100);

  sendCommand(0x29);
  
  Delay(100);

  sendCommand(TFT_REG_MEM_WRITE);
  setBacklight(50);
	    
}
    
void sendRegister(unsigned int reg)
{
  pushDataRam(reg);
}

void sendCommand(unsigned int data)
{
  pushDataReg(data);
}

void sendData(unsigned int data)
{
  pushDataRam(data);
}

void pushDataReg(unsigned int data)
{
  ili9341_WriteReg(data);
}

void pushDataRam(unsigned int data)
{
  ili9341_WriteData(data);
}

void tftReset()
{
  Delay(10);
  Delay(15);
  Delay(120);
  ili9341_WriteReg(LCD_SWRESET);
  Delay(120);
}

void enterSleep()
{
  sendCommand(0x28);
  Delay(20);
  sendCommand(0x10);
}

void exitSleep()
{
  sendCommand(0x11);
  Delay(120);
  sendCommand(0x29);
}

#if 0
void setOrientation(unsigned int HV)
{
  sendCommand(0x03);
  if(HV==1)//vertical
  {
    sendData(0x5038);
  }
  else//horizontal
  {
    sendData(0x5030);
  }
  sendCommand(0x0022); //Start to write to display RAM
}
#endif

void setCol(uint16_t startX, uint16_t startY)
{
  sendCommand(0x2A);
  sendRegister(startX);
  sendRegister(startY);
}

void setPage(uint16_t endX, uint16_t endY)
{
  sendCommand(0x2B);
  sendRegister(endX);
  sendRegister(endY);
}

void setXY(uint16_t poX, uint16_t poY)
{
  //setCol(poX, poX);
  setPage(poY, poY);
  sendCommand(TFT_REG_MEM_WRITE);
}
void setWindow(uint16_t startX, uint16_t endX, uint16_t startY, uint16_t endY)
 {
    /*
    sendCommand(0x2a);
    
    sendRegister((startX >> 8) & 0xFF);
    sendRegister(startX & 0xFF);
    sendRegister((endX >> 8) & 0xFF);
    sendRegister(startY & 0xFF);
  
    sendCommand(0x2b);
    sendRegister((startY >> 8) & 0xFF);
    sendRegister(endX & 0xFF);
    sendRegister((endY >> 8) & 0xFF);
    sendRegister(endY >> 8);
    */
    sendCommand(TFT_REG_COL);
    sendRegister(startX >> 8);
    sendRegister(startX);
    sendRegister(endX >> 8);
    sendRegister(endX);
    sendCommand(TFT_REG_PAGE);
    sendRegister(startY >> 8);
    sendRegister(startY);
    sendRegister(endY >> 8);
    sendRegister(endY);


    sendCommand(TFT_REG_MEM_WRITE);
 }
#if 0
void fillRectangle(uint16_t poX, uint16_t poY,
                                uint16_t width, uint16_t length,
                                uint16_t color)
{
  uint32_t windowSize = length * width;
  uint32_t count = 0;

  setWindow(poX, (poX + width), poY, (poY + length));
  /*for( uint32_t i = 0; i <= windowSize; i++ )
  {
    sendData(color);
    count++;
  }
  sendData(color);  */
  int i = 0;
  int j = 0;
  for( i = 0; i < length; i++ )
  {
    for( j = 0; j < width + 100; j++ )
    {
      sendData(color);
    }
  }
}
#endif
void color_convert(uint16_t color,uint8_t* result)
{
	//~ #define RED             0xF800
	//~ #define BLUE            0x001F
	//~ #define GREEN           0x07E0
	result[2]=  ((color&0x1f)		<<(1+2))<<1;//|0x80;    //5 bit BLUE
	result[1]=  (((color>>5)&0x3f) <<(0+1))<<1;//|0x80;    //6 bit GREEN
	result[0]=  (((color>>11)&0x1f)<<(1+2))<<1;//|0x80;    //5 bit  //RED
}

uint16_t color_convertRGB_to16(uint8_t * adress)
{
	return ((adress[0]>>3)<<11)|((adress[1]>>2)<<5)|(adress[2]>>3);
}
void LCD_SetWindows(uint16_t xStar, uint16_t yStar,uint16_t xEnd,uint16_t yEnd);

void LCD_fillRect2(uint16_t x1, uint16_t y1, uint16_t w, uint16_t h, uint16_t color)
{
	int dw = w*h;
	//setWindow(x1, x1+w-1, y1, y1+h-1);
	LCD_SetWindows(x1,y1,x1+w-1,y1+h-1);
	int k;
	for(k=0;k<dw;k++)
	{
		//sendData(color);
		LCD_RAM = color;
	}
	///fillRectangle(x1,y1,w,h,color);
}
uint16_t rbuff[2][64*6];
static int bp = 0;
volatile int bComplete = 1;
extern DMA_HandleTypeDef hdma_memtomem_dma2_stream3;
extern DMA_HandleTypeDef hdma_memtomem_dma2_stream4;
void MyDMAComplete(DMA_HandleTypeDef* hdma)
{
	bComplete = 1;
}

void LCD_fillRect(uint16_t x1, uint16_t y1, uint16_t w, uint16_t h, uint16_t color)
{
	int dw = w*h;
	//setWindow(x1, x1+w-1, y1, y1+h-1);
	LCD_SetWindows(x1,y1,x1+w-1,y1+h-1);
	int k;
#define BSIZ 0x8000
	if(dw>=4)
	{
		/*
		uint16_t dtt[BSIZ];
		int fn = dw>BSIZ?BSIZ:dw;
		for(int k=0;k<fn;k++)
		{
			dtt[k] = color;
		}
		*/
		for(k=dw;k>0;k -= BSIZ)
		{
			bComplete = 0;
			HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream4, &color, &LCD_RAM,k>=BSIZ?(BSIZ):(k));
			while(!bComplete)
			{

			}
		}
	}
	else
	{
		for(k=0;k<dw;k++)
		{
			//sendData(color);
			LCD_RAM = color;
		}
	}
	///fillRectangle(x1,y1,w,h,color);
}
void LCD_fillRectScale(uint16_t x1, uint16_t y1, uint16_t w, uint16_t h, uint16_t color,int SCALE)
{
	int dw = w*h;
	//setWindow(x1, x1+w-1, y1, y1+h-1);
	while(!bComplete)
	{

	}
	LCD_SetWindows(x1*SCALE,y1*SCALE,x1*SCALE+w*SCALE-1,y1*SCALE+h*SCALE-1);
	int k;
#define BSIZ 0x8000
	dw *= SCALE*SCALE;
	if(dw>=4)
	{
		/*
		uint16_t dtt[BSIZ];
		int fn = dw>BSIZ?BSIZ:dw;
		for(int k=0;k<fn;k++)
		{
			dtt[k] = color;
		}
		*/
		for(k=dw;k>0;k -= BSIZ)
		{
			bComplete = 0;
			HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream4, &color, &LCD_RAM,k>=BSIZ?(BSIZ):(k));
			while(!bComplete)
			{

			}
		}
	}
	else
	{
		for(k=0;k<dw;k++)
		{
			//sendData(color);
			LCD_RAM = color;
		}
	}
	///fillRectangle(x1,y1,w,h,color);
}
void LCD_fillRectR(uint16_t x1, uint16_t y1, uint16_t w, uint16_t h, uint16_t color)
{
	int dw = w*h;
	//setWindow(x1, x1+w-1, y1, y1+h-1);
	LCD_SetWindows(x1,y1,x1+w-1,y1+h-1);
	int k;
	for(k=0;k<dw;k++)
	{
		//sendData(color);
		LCD_RAM = color;
	}
	///fillRectangle(x1,y1,w,h,color);
}
void LCD_Write8x8lineA(uint16_t x1, uint16_t y1,uint8_t * adress)
{
	//setWindow(x1, (uint16_t) (x1+8-1),y1,(uint16_t) (y1+8-1));
	LCD_SetWindows(x1,y1,(uint16_t) (x1+8-1),(uint16_t) (y1+8-1));
	uint16_t ncolor;
	int k;
	for(k=0;k<8*8;k++)
	{
		uint16_t color = color_convertRGB_to16(adress);
		LCD_RAM = color;
		//sendData(color);
		adress+=3;
	}
}
void makeBlock8(uint16_t * colors,uint8_t * bytes,uint16_t*  block8,int stride)
{
	int k;
	for(int k=0;k<3;k++)
	{
		colors[k] = __REV16(colors[k]);
	}
	for(int yy=0;yy<4;yy++)
	{
		for(int xx=0;xx<4;xx++)
		{
			int16_t rnum = (((bytes[yy*2]>>((3-xx)*2))&3)<<2)|((bytes[yy*2+1]>>((3-xx)*2))&3);
			for(int y=0;y<2;y++)
			{
				uint16_t*  block8p = &block8[(yy*2+y)*stride+xx*2];
				for(int x=0;x<2;x++)
				{
					block8p[x] = colors[ttab[rnum][y][x]];
				}
			}
		}
	}
}
void waitScreenComplete()
{
	while(!bComplete)
	{

	}
}

void makeBlock16(uint16_t * colors,uint8_t * bytes,uint16_t*  block16,int stride)
{
	int k;
	for(int k=0;k<3;k++)
	{
		//colors[k] = __REV16(colors[k]);
	}
	for(int yy=0;yy<4;yy++)
	{
		for(int xx=0;xx<4;xx++)
		{
			int16_t rnum = (((bytes[yy*2]>>((3-xx)*2))&3)<<2)|((bytes[yy*2+1]>>((3-xx)*2))&3);
			for(int y=0;y<4;y++)
			{
				uint16_t*  block16p = &block16[(yy*4+y)*stride+xx*4];
				for(int x=0;x<4;x++)
				{
					block16p[x] = colors[ttab[rnum][y][x]];
				}
			}
		}
	}
}


void LCD_Write8x8line(uint16_t x1, uint16_t y1,uint8_t * adress)
{
	//setWindow(x1, (uint16_t) (x1+8-1),y1,(uint16_t) (y1+8-1));
	uint16_t ncolor[8];
	int k;
	bp = (bp+1)&1;
	uint16_t * BPPNT = rbuff[bp];
	for(int y=0;y<8;y++)
	{
		for(int x=0;x<8;x++)
		{
			ncolor[x] = color_convertRGB_to16(adress);
			*BPPNT++ = ncolor[x];
			*BPPNT++ = ncolor[x];
			adress+=3;
		}
		for(int x=0;x<8;x++)
		{
			*BPPNT++ = ncolor[x];
			*BPPNT++ = ncolor[x];
		}
	}
	while(bComplete!=1)
	{

	}
	bComplete = 0;
	LCD_SetWindows(x1*2,y1*2,(uint16_t) (x1*2+8*2-1),(uint16_t) (y1*2+8*2-1));
	/*
	for(int y=0;y<8;y++)
	{
		for(int x=0;x<8;x++)
		{
			ncolor[x] = color_convertRGB_to16(adress);
			LCD_RAM = ncolor[x];
			LCD_RAM = ncolor[x];
			adress+=3;
		}
		for(int x=0;x<8;x++)
		{
			LCD_RAM = ncolor[x];
			LCD_RAM = ncolor[x];
		}
	}
	*/
	//for(int k=0;k<64*4;k++)
	//{
	//	LCD_RAM = rbuff[k];
	//}
	HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream3, rbuff[bp], &LCD_RAM,64*4);
//	while(bComplete!=1)
//	{
//
//	}
	//HAL_DMA_PollForTransfer(&hdma_memtomem_dma2_stream1,HAL_DMA_FULL_TRANSFER,1000);
	//while(HAL_DMA_STATE_READY != hdma_memtomem_dma2_stream1.State){};
}
void LCD_Write8x8line16p2(uint16_t x1, uint16_t y1,uint16_t * adress)
{
	//setWindow(x1, (uint16_t) (x1+8-1),y1,(uint16_t) (y1+8-1));
	uint16_t ncolor[8];
	int k;
	bp = (bp+1)&1;
	uint16_t * BPPNT = rbuff[bp];
	for(int y=0;y<8;y++)
	{
		for(int x=0;x<8;x++)
		{
			ncolor[x] = *adress;
			*BPPNT++ = ncolor[x];
			*BPPNT++ = ncolor[x];
			adress++;
		}
		for(int x=0;x<8;x++)
		{
			*BPPNT++ = ncolor[x];
			*BPPNT++ = ncolor[x];
		}
	}
	while(bComplete!=1)
	{

	}
	bComplete = 0;
	LCD_SetWindows(x1*2,y1*2,(uint16_t) (x1*2+8*2-1),(uint16_t) (y1*2+8*2-1));
	/*
	for(int y=0;y<8;y++)
	{
		for(int x=0;x<8;x++)
		{
			ncolor[x] = color_convertRGB_to16(adress);
			LCD_RAM = ncolor[x];
			LCD_RAM = ncolor[x];
			adress+=3;
		}
		for(int x=0;x<8;x++)
		{
			LCD_RAM = ncolor[x];
			LCD_RAM = ncolor[x];
		}
	}
	*/
	//for(int k=0;k<64*4;k++)
	//{
	//	LCD_RAM = rbuff[k];
	//}
	HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream3, rbuff[bp], &LCD_RAM,64*4);
//	while(bComplete!=1)
//	{
//
//	}
	//HAL_DMA_PollForTransfer(&hdma_memtomem_dma2_stream1,HAL_DMA_FULL_TRANSFER,1000);
	//while(HAL_DMA_STATE_READY != hdma_memtomem_dma2_stream1.State){};
}
void LCD_Write8x8line16_2_16_32(uint16_t x1, uint16_t y1,uint16_t*  block16)
{
	int x1n = x1;
	int y1n = y1;
	while(!bComplete)
	{

	}
	//setWindow(x1n, (uint16_t) (x1n+8*32-1),y1n,(uint16_t) (y1n+8-1));
	LCD_SetWindows(x1*2,y1*2,(uint16_t) (x1*2+32*16-1),(uint16_t) (y1*2+16-1));
  //  FMC_BANK1_WriteComand(TFT_REG_MEM_WRITE);
	bComplete = 0;
	//HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream3, rbuff[bp], &LCD_RAM,64*4);
	HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream3, &block16[0], &LCD_RAM,16*16*32);
}


void LCD_Write8x8line16p(uint16_t x1, uint16_t y1,uint16_t * adress)
{
	//setWindow(x1, (uint16_t) (x1+8-1),y1,(uint16_t) (y1+8-1));
	uint16_t ncolor[8];
	int k;
	bp = (bp+1)&1;
	uint16_t * BPPNT = rbuff[bp];
	for(int y=0;y<8;y++)
	{
		for(int x=0;x<8;x++)
		{
			ncolor[x] = *adress;
			*BPPNT++ = ncolor[x];
			adress++;
		}
	}
	while(bComplete!=1)
	{

	}
	bComplete = 0;
	LCD_SetWindows(x1,y1,(uint16_t) (x1+8-1),(uint16_t) (y1+8-1));
	/*
	for(int y=0;y<8;y++)
	{
		for(int x=0;x<8;x++)
		{
			ncolor[x] = color_convertRGB_to16(adress);
			LCD_RAM = ncolor[x];
			LCD_RAM = ncolor[x];
			adress+=3;
		}
		for(int x=0;x<8;x++)
		{
			LCD_RAM = ncolor[x];
			LCD_RAM = ncolor[x];
		}
	}
	*/
	//for(int k=0;k<64*4;k++)
	//{
	//	LCD_RAM = rbuff[k];
	//}
	HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream3, rbuff[bp], &LCD_RAM,64);
//	while(bComplete!=1)
//	{
//
//	}
	//HAL_DMA_PollForTransfer(&hdma_memtomem_dma2_stream1,HAL_DMA_FULL_TRANSFER,1000);
	//while(HAL_DMA_STATE_READY != hdma_memtomem_dma2_stream1.State){};
}
void LCD_Write8x8line16(uint16_t x1, uint16_t y1,uint16_t * adress)
{
	//setWindow(x1, (uint16_t) (x1+8-1),y1,(uint16_t) (y1+8-1));
	uint16_t ncolor[8];
	int k;
	bp = (bp+1)&1;
	uint16_t * BPPNT = rbuff[bp];
	for(int y=0;y<8;y++)
	{
		for(int x=0;x<8;x++)
		{
			ncolor[x] = *adress;
			*BPPNT++ = ncolor[x];
			*BPPNT++ = ncolor[x];
			*BPPNT++ = ncolor[x];
			adress++;
		}
		for(int x=0;x<8;x++)
		{
			*BPPNT++ = ncolor[x];
			*BPPNT++ = ncolor[x];
			*BPPNT++ = ncolor[x];
		}
	}
	while(bComplete!=1)
	{

	}
	bComplete = 0;
	LCD_SetWindows(x1*3,y1*2,(uint16_t) (x1*3+8*3-1),(uint16_t) (y1*2+8*2-1));
	/*
	for(int y=0;y<8;y++)
	{
		for(int x=0;x<8;x++)
		{
			ncolor[x] = color_convertRGB_to16(adress);
			LCD_RAM = ncolor[x];
			LCD_RAM = ncolor[x];
			adress+=3;
		}
		for(int x=0;x<8;x++)
		{
			LCD_RAM = ncolor[x];
			LCD_RAM = ncolor[x];
		}
	}
	*/
	//for(int k=0;k<64*4;k++)
	//{
	//	LCD_RAM = rbuff[k];
	//}
	HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream3, rbuff[bp], &LCD_RAM,64*6);
//	while(bComplete!=1)
//	{
//
//	}
	//HAL_DMA_PollForTransfer(&hdma_memtomem_dma2_stream1,HAL_DMA_FULL_TRANSFER,1000);
	//while(HAL_DMA_STATE_READY != hdma_memtomem_dma2_stream1.State){};
}
void LCD_FullRect3A(uint16_t x1, uint16_t y1,uint8_t * adress,uint16_t w,uint16_t h)
{
	int dw = w*h;
	//setWindow(x1, x1+w-1, y1, y1+h-1);
	LCD_SetWindows(x1,y1,x1+w-1,y1+h-1);
	int k;
	 uint16_t color = color_convertRGB_to16(adress);
	for(k=0;k<dw;k++)
	{
		LCD_RAM = color;
		//sendData(color);
	}

}
void LCD_FullRect3(uint16_t x1, uint16_t y1,uint8_t * adress,uint16_t w,uint16_t h)
{
	int dw = w*h;
	//setWindow(x1, x1+w-1, y1, y1+h-1);
	int k;
	uint16_t color = color_convertRGB_to16(adress);
	while(bComplete!=1)
	{

	}
	bComplete = 0;
	LCD_SetWindows(x1,y1,x1+w-1,y1+h-1);
	for(k=0;k<dw;k++)
	{
		LCD_RAM = color;
	}
	bComplete = 1;
}

uint16_t ili9341_ReadID(void)
{
  //~ LCD_IO_Init();
  return ((uint16_t) ili9341_ReadData(LCD_READ_ID4) );
}

uint32_t ili9341_ReadData(uint16_t RegValue)
{
  /* Read a max of 4 bytes */
  return (LCD_IO_ReadData(RegValue));
}
/*
static uint16_t screen_width  = ILI9341_LCD_PIXEL_WIDTH;
static uint16_t screen_height = ILI9341_LCD_PIXEL_HEIGHT;
#define MADCTL_MY  0x80
#define MADCTL_MX  0x40
#define MADCTL_MV  0x20
#define MADCTL_ML  0x10
#define MADCTL_RGB 0x00
#define MADCTL_BGR 0x08
#define MADCTL_MH  0x04

void LCD_setRotation(uint8_t rotation)
{
    screen_height = ILI9341_LCD_PIXEL_HEIGHT;
    screen_width  = ILI9341_LCD_PIXEL_WIDTH;
	uint8_t madctl = 0;
	switch (rotation&0x3) {
	  case PORTRAIT:
		madctl = (MADCTL_MX | MADCTL_BGR);
		break;
	  case LANDSCAPE:
		madctl = (MADCTL_MV | MADCTL_BGR);
        screen_height = ILI9341_LCD_PIXEL_WIDTH;
        screen_width  = ILI9341_LCD_PIXEL_HEIGHT;
		break;
	  case PORTRAIT_FLIP:
		madctl = (MADCTL_MY | MADCTL_BGR);
		break;
	  case LANDSCAPE_FLIP:
		madctl = (MADCTL_MX | MADCTL_MY | MADCTL_MV | MADCTL_BGR);
        screen_height = ILI9341_LCD_PIXEL_WIDTH;
        screen_width  = ILI9341_LCD_PIXEL_HEIGHT;
		break;
	}
	  ili9341_WriteReg(LCD_MAC);
	  ili9341_WriteData(madctl);
//    TFT_CS_RESET;
//    dmaSendCmdCont(LCD_MAC);
//    dmaSendDataCont8(&madctl, 1);
//    TFT_CS_SET;
}
uint16_t LCD_getWidth() {
    return screen_width;
}
*/
typedef uint16_t u16;
typedef uint8_t u8;
typedef struct
{
	u16 width;			//LCD ¿í¶È
	u16 height;			//LCD ¸ß¶È
	u16 id;				//LCD ID
	u8  dir;			//ºáÆÁ»¹ÊÇÊúÆÁ¿ØÖÆ£º0£¬ÊúÆÁ£»1£¬ºáÆÁ¡£
	u16	 wramcmd;		//¿ªÊ¼Ð´gramÖ¸Áî
	u16  rramcmd;   //¿ªÊ¼¶ÁgramÖ¸Áî
	u16  setxcmd;		//ÉèÖÃx×ø±êÖ¸Áî
	u16  setycmd;		//ÉèÖÃy×ø±êÖ¸Áî
}_lcd_dev;
#define LCD_W 480
#define LCD_H 800


_lcd_dev lcddev;

#define USE_HORIZONTAL  	 0
void LCD_direction(u8 direction)
{
	lcddev.setxcmd=0x2A00;
	lcddev.setycmd=0x2B00;
	lcddev.wramcmd=0x2C00;
	lcddev.rramcmd=0x2E00;
	switch(direction){
		case 0:
			lcddev.width=LCD_W;
			lcddev.height=LCD_H;
			LCD_WriteReg(0x3600,0x00);
		break;
		case 1:
			lcddev.width=LCD_H;
			lcddev.height=LCD_W;
			LCD_WriteReg(0x3600,(1<<5)|(1<<6));
		break;
		case 2:
			lcddev.width=LCD_W;
			lcddev.height=LCD_H;
			LCD_WriteReg(0x3600,(1<<7)|(1<<6));
		break;
		case 3:
			lcddev.width=LCD_H;
			lcddev.height=LCD_W;
			LCD_WriteReg(0x3600,(1<<7)|(1<<5));
		break;
		default:break;
	}
}
void LCD_setRotation(uint8_t rotation)
{
	LCD_direction(rotation);
}
uint16_t LCD_getWidth() {
    return lcddev.width;
}

uint16_t LCD_getHeight() {
    return lcddev.height;
}
void LCD_Clear(uint16_t Color)
{
  unsigned int i;//,m;
	uint32_t  total_point=lcddev.width*lcddev.height;
	LCD_SetWindows(0,0,lcddev.width-1,lcddev.height-1);
	for(i=0;i<total_point;i++)
	{
		LCD_RAM = Color;
	}
}

void LCD_SINIT()
{
	  HAL_DMA_RegisterCallback(&hdma_memtomem_dma2_stream3,HAL_DMA_XFER_CPLT_CB_ID,MyDMAComplete);
	  HAL_DMA_RegisterCallback(&hdma_memtomem_dma2_stream4,HAL_DMA_XFER_CPLT_CB_ID,MyDMAComplete);
	//3.97inch OTM8009 Init 20190116
	LCD_WR_REG(0x0100);
	HAL_Delay(10);
	LCD_WR_REG(0xff00);
	LCD_WR_DATA(0x80);
	LCD_WR_REG(0xff01);
	LCD_WR_DATA(0x09);
	LCD_WR_REG(0xff02);
	LCD_WR_DATA(0x01);

	LCD_WR_REG(0xff80);
	LCD_WR_DATA(0x80);
	LCD_WR_REG(0xff81);
	LCD_WR_DATA(0x09);

	LCD_WR_REG(0xff03);
	LCD_WR_DATA(0x01);

	//add ==========20131216============================//
	LCD_WR_REG(0xf5b6);
	LCD_WR_DATA(0x06);
	LCD_WR_REG(0xc480);
	LCD_WR_DATA(0x30);
	LCD_WR_REG(0xc48a);
	LCD_WR_DATA(0x40);
	//===================================================//
	LCD_WR_REG(0xc0a3);
	LCD_WR_DATA(0x1B);

	//LCD_WR_REG(0xc0ba);  //No
	//LCD_WR_DATA(0x50);

	LCD_WR_REG(0xc0ba); //--> (0xc0b4); // column inversion //  2013.12.16 modify
	LCD_WR_DATA(0x50);

	LCD_WR_REG(0xc181);
	LCD_WR_DATA(0x66);

	LCD_WR_REG(0xc1a1);
	LCD_WR_DATA(0x0E);

	LCD_WR_REG(0xc481);
	LCD_WR_DATA(0x83);

	LCD_WR_REG(0xc582);
	LCD_WR_DATA(0x83);

	LCD_WR_REG(0xc590);
	LCD_WR_DATA(0x96);

	LCD_WR_REG(0xc591);
	LCD_WR_DATA(0x2B);

	LCD_WR_REG(0xc592);
	LCD_WR_DATA(0x01);


	LCD_WR_REG(0xc594);
	LCD_WR_DATA(0x33);

	LCD_WR_REG(0xc595);
	LCD_WR_DATA(0x34);


	LCD_WR_REG(0xc5b1);
	LCD_WR_DATA(0xa9);

	LCD_WR_REG(0xce80);
	LCD_WR_DATA(0x86);
	LCD_WR_REG(0xce81);
	LCD_WR_DATA(0x01);
	LCD_WR_REG(0xce82);
	LCD_WR_DATA(0x00);

	LCD_WR_REG(0xce83);
	LCD_WR_DATA(0x85);
	LCD_WR_REG(0xce84);
	LCD_WR_DATA(0x01);
	LCD_WR_REG(0xce85);
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xce86);
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xce87);
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xce88);
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xce89);
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xce8A);
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xce8B);
	LCD_WR_DATA(0x00);

	LCD_WR_REG(0xcea0);// cea1[7:0] : clka1_width[3:0], clka1_shift[11:8]
	LCD_WR_DATA(0x18);
	LCD_WR_REG(0xcea1);// cea2[7:0] : clka1_shift[7:0]
	LCD_WR_DATA(0x04);
	LCD_WR_REG(0xcea2);// cea3[7:0] : clka1_sw_tg, odd_high, flat_head, flat_tail, switch[11:8]
	LCD_WR_DATA(0x03);
	LCD_WR_REG(0xcea3);// cea4[7:0] : clka1_switch[7:0]
	LCD_WR_DATA(0x21);
	LCD_WR_REG(0xcea4);// cea5[7:0] : clka1_extend[7:0]
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcea5);// cea6[7:0] : clka1_tchop[7:0]
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcea6);// cea7[7:0] : clka1_tglue[7:0]
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcea7);// cea8[7:0] : clka2_width[3:0], clka2_shift[11:8]
	LCD_WR_DATA(0x18);
	LCD_WR_REG(0xcea8);// cea9[7:0] : clka2_shift[7:0]
	LCD_WR_DATA(0x03);
	LCD_WR_REG(0xcea9);// ceaa[7:0] : clka2_sw_tg, odd_high, flat_head, flat_tail, switch[11:8]
	LCD_WR_DATA(0x03);
	LCD_WR_REG(0xceaa);// ceab[7:0] : clka2_switch[7:0]
	LCD_WR_DATA(0x22);
	LCD_WR_REG(0xceab);// ceac[7:0] : clka2_extend
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xceac);// cead[7:0] : clka2_tchop
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcead);// ceae[7:0] : clka2_tglue
	LCD_WR_DATA(0x00);

	LCD_WR_REG(0xceb0);// ceb1[7:0] : clka3_width[3:0], clka3_shift[11:8]
	LCD_WR_DATA(0x18);
	LCD_WR_REG(0xceb1);// ceb2[7:0] : clka3_shift[7:0]
	LCD_WR_DATA(0x02);
	LCD_WR_REG(0xceb2);// ceb3[7:0] : clka3_sw_tg, odd_high, flat_head, flat_tail, switch[11:8]
	LCD_WR_DATA(0x03);
	LCD_WR_REG(0xceb3);// ceb4[7:0] : clka3_switch[7:0]
	LCD_WR_DATA(0x23);
	LCD_WR_REG(0xceb4);// ceb5[7:0] : clka3_extend[7:0]
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xceb5);// ceb6[7:0] : clka3_tchop[7:0]
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xceb6);// ceb7[7:0] : clka3_tglue[7:0]
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xceb7);// ceb8[7:0] : clka4_width[3:0], clka2_shift[11:8]
	LCD_WR_DATA(0x18);
	LCD_WR_REG(0xceb8);// ceb9[7:0] : clka4_shift[7:0]
	LCD_WR_DATA(0x01);
	LCD_WR_REG(0xceb9);// ceba[7:0] : clka4_sw_tg, odd_high, flat_head, flat_tail, switch[11:8]
	LCD_WR_DATA(0x03);
	LCD_WR_REG(0xceba);// cebb[7:0] : clka4_switch[7:0]
	LCD_WR_DATA(0x24);
	LCD_WR_REG(0xcebb);// cebc[7:0] : clka4_extend
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcebc);// cebd[7:0] : clka4_tchop
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcebd);// cebe[7:0] : clka4_tglue
	LCD_WR_DATA(0x00);


	LCD_WR_REG(0xcfc0);// cfc1[7:0] : eclk_normal_width[7:0]
	LCD_WR_DATA(0x01);
	LCD_WR_REG(0xcfc1);// cfc2[7:0] : eclk_partial_width[7:0]
	LCD_WR_DATA(0x01);
	LCD_WR_REG(0xcfc2);// cfc3[7:0] : all_normal_tchop[7:0]
	LCD_WR_DATA(0x20);
	LCD_WR_REG(0xcfc3);// cfc4[7:0] : all_partial_tchop[7:0]
	LCD_WR_DATA(0x20);
	LCD_WR_REG(0xcfc4);// cfc5[7:0] : eclk1_follow[3:0], eclk2_follow[3:0]
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcfc5);// cfc6[7:0] : eclk3_follow[3:0], eclk4_follow[3:0]
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcfc6);// cfc7[7:0] : 00, vstmask, vendmask, 00, dir1, dir2 (0=VGL, 1=VGH)
	LCD_WR_DATA(0x01);
	LCD_WR_REG(0xcfc7);// cfc8[7:0] : reg_goa_gnd_opt, reg_goa_dpgm_tail_set, reg_goa_f_gating_en, reg_goa_f_odd_gating, toggle_mod1, 2, 3, 4
	LCD_WR_DATA(0x00);    // GND OPT1 (00-->80  2011/10/28)
	LCD_WR_REG(0xcfc8);// cfc9[7:0] : duty_block[3:0], DGPM[3:0]
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcfc9);// cfca[7:0] : reg_goa_gnd_period[7:0]
	LCD_WR_DATA(0x00);    // Gate PCH (CLK base) (00-->0a  2011/10/28)

	LCD_WR_REG(0xcfd0);// cfd1[7:0] : 0000000, reg_goa_frame_odd_high
	LCD_WR_DATA(0x00);

	LCD_WR_REG(0xcbc0);//cbc1[7:0] : enmode H-byte of sig1  (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbc1);//cbc2[7:0] : enmode H-byte of sig2  (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x04);
	LCD_WR_REG(0xcbc2);//cbc3[7:0] : enmode H-byte of sig3  (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x04);
	LCD_WR_REG(0xcbc3);//cbc4[7:0] : enmode H-byte of sig4  (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x04);
	LCD_WR_REG(0xcbc4);//cbc5[7:0] : enmode H-byte of sig5  (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x04);
	LCD_WR_REG(0xcbc5);//cbc6[7:0] : enmode H-byte of sig6  (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x04);
	LCD_WR_REG(0xcbc6);//cbc7[7:0] : enmode H-byte of sig7  (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbc7);//cbc8[7:0] : enmode H-byte of sig8  (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbc8);//cbc9[7:0] : enmode H-byte of sig9  (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbc9);//cbca[7:0] : enmode H-byte of sig10 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbca);//cbcb[7:0] : enmode H-byte of sig11 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbcb);//cbcc[7:0] : enmode H-byte of sig12 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbcc);//cbcd[7:0] : enmode H-byte of sig13 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbcd);//cbce[7:0] : enmode H-byte of sig14 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbce);//cbcf[7:0] : enmode H-byte of sig15 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);

	LCD_WR_REG(0xcbd0);//cbd1[7:0] : enmode H-byte of sig16 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbd1);//cbd2[7:0] : enmode H-byte of sig17 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbd2);//cbd3[7:0] : enmode H-byte of sig18 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbd3);//cbd4[7:0] : enmode H-byte of sig19 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbd4);//cbd5[7:0] : enmode H-byte of sig20 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbd5);//cbd6[7:0] : enmode H-byte of sig21 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbd6);//cbd7[7:0] : enmode H-byte of sig22 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x04);
	LCD_WR_REG(0xcbd7);//cbd8[7:0] : enmode H-byte of sig23 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x04);
	LCD_WR_REG(0xcbd8);//cbd9[7:0] : enmode H-byte of sig24 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x04);
	LCD_WR_REG(0xcbd9);//cbda[7:0] : enmode H-byte of sig25 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x04);
	LCD_WR_REG(0xcbda);//cbdb[7:0] : enmode H-byte of sig26 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x04);
	LCD_WR_REG(0xcbdb);//cbdc[7:0] : enmode H-byte of sig27 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbdc);//cbdd[7:0] : enmode H-byte of sig28 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbdd);//cbde[7:0] : enmode H-byte of sig29 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbde);//cbdf[7:0] : enmode H-byte of sig30 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);

	LCD_WR_REG(0xcbe0);//cbe1[7:0] : enmode H-byte of sig31 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbe1);//cbe2[7:0] : enmode H-byte of sig32 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbe2);//cbe3[7:0] : enmode H-byte of sig33 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbe3);//cbe4[7:0] : enmode H-byte of sig34 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbe4);//cbe5[7:0] : enmode H-byte of sig35 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbe5);//cbe6[7:0] : enmode H-byte of sig36 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbe6);//cbe7[7:0] : enmode H-byte of sig37 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbe7);//cbe8[7:0] : enmode H-byte of sig38 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbe8);//cbe9[7:0] : enmode H-byte of sig39 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcbe9);//cbea[7:0] : enmode H-byte of sig40 (pwrof_0, pwrof_1, norm, pwron_4 )
	LCD_WR_DATA(0x00);

	// cc8x
	LCD_WR_REG(0xcc80);//cc81[7:0] : reg setting for signal01 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc81);//cc82[7:0] : reg setting for signal02 selection with u2d mode
	LCD_WR_DATA(0x26);
	LCD_WR_REG(0xcc82);//cc83[7:0] : reg setting for signal03 selection with u2d mode
	LCD_WR_DATA(0x09);
	LCD_WR_REG(0xcc83);//cc84[7:0] : reg setting for signal04 selection with u2d mode
	LCD_WR_DATA(0x0B);
	LCD_WR_REG(0xcc84);//cc85[7:0] : reg setting for signal05 selection with u2d mode
	LCD_WR_DATA(0x01);
	LCD_WR_REG(0xcc85);//cc86[7:0] : reg setting for signal06 selection with u2d mode
	LCD_WR_DATA(0x25);
	LCD_WR_REG(0xcc86);//cc87[7:0] : reg setting for signal07 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc87);//cc88[7:0] : reg setting for signal08 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc88);//cc89[7:0] : reg setting for signal09 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc89);//cc8a[7:0] : reg setting for signal10 selection with u2d mode
	LCD_WR_DATA(0x00);

	// cc9x
	LCD_WR_REG(0xcc90);//cc91[7:0] : reg setting for signal11 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc91);//cc92[7:0] : reg setting for signal12 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc92);//cc93[7:0] : reg setting for signal13 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc93);//cc94[7:0] : reg setting for signal14 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc94);//cc95[7:0] : reg setting for signal15 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc95);//cc96[7:0] : reg setting for signal16 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc96);//cc97[7:0] : reg setting for signal17 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc97);//cc98[7:0] : reg setting for signal18 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc98);//cc99[7:0] : reg setting for signal19 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc99);//cc9a[7:0] : reg setting for signal20 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc9a);//cc9b[7:0] : reg setting for signal21 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcc9b);//cc9c[7:0] : reg setting for signal22 selection with u2d mode
	LCD_WR_DATA(0x26);
	LCD_WR_REG(0xcc9c);//cc9d[7:0] : reg setting for signal23 selection with u2d mode
	LCD_WR_DATA(0x0A);
	LCD_WR_REG(0xcc9d);//cc9e[7:0] : reg setting for signal24 selection with u2d mode
	LCD_WR_DATA(0x0C);
	LCD_WR_REG(0xcc9e);//cc9f[7:0] : reg setting for signal25 selection with u2d mode
	LCD_WR_DATA(0x02);
	// ccax
	LCD_WR_REG(0xcca0);//cca1[7:0] : reg setting for signal26 selection with u2d mode
	LCD_WR_DATA(0x25);
	LCD_WR_REG(0xcca1);//cca2[7:0] : reg setting for signal27 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcca2);//cca3[7:0] : reg setting for signal28 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcca3);//cca4[7:0] : reg setting for signal29 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcca4);//cca5[7:0] : reg setting for signal20 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcca5);//cca6[7:0] : reg setting for signal31 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcca6);//cca7[7:0] : reg setting for signal32 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcca7);//cca8[7:0] : reg setting for signal33 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcca8);//cca9[7:0] : reg setting for signal34 selection with u2d mode
	LCD_WR_DATA(0x00);
	LCD_WR_REG(0xcca9);//ccaa[7:0] : reg setting for signal35 selection with u2d mode
	LCD_WR_DATA(0x00);

  LCD_WR_REG(0x3A00);//ccaa[7:0] : reg setting for signal35 selection with u2d mode
	LCD_WR_DATA(0x55);//0x55

	LCD_WR_REG(0x1100);
	HAL_Delay(100);
	LCD_WR_REG(0x2900);
	HAL_Delay(50);
	LCD_WR_REG(0x2C00);

  LCD_direction(USE_HORIZONTAL);//ÉèÖÃLCDÏÔÊ¾·½Ïò
	//LCD_Clear(WHITE);//ÇåÈ«ÆÁ°×É«
	//HAL_Delay(100);
	//LCD_Clear(RED);//ÇåÈ«ÆÁ°×É«
	//HAL_Delay(100);
	//LCD_Clear(GREEN);//ÇåÈ«ÆÁ°×É«
	//HAL_Delay(100);
	LCD_Clear(BLACK);//ÇåÈ«ÆÁ°×É«


}
void display_off()
{
	LCD_WR_REG(0x2800);
}
void display_on()
{
	LCD_WR_REG(0x2900);
}

/*****************************************************************************
 * @name       :void LCD_WriteRAM_Prepare(void)
 * @date       :2018-08-09
 * @function   :Write GRAM
 * @parameters :None
 * @retvalue   :None
******************************************************************************/
void LCD_WriteRAM_Prepare(void)
{
	LCD_WR_REG(lcddev.wramcmd);
}

/*****************************************************************************
 * @name       :void LCD_ReadRAM_Prepare(void)
 * @date       :2018-11-13
 * @function   :Read GRAM
 * @parameters :None
 * @retvalue   :None
******************************************************************************/
void LCD_ReadRAM_Prepare(void)
{
	LCD_WR_REG(lcddev.rramcmd);
}

/*****************************************************************************
 * @name       :void LCD_SetWindows(u16 xStar, u16 yStar,u16 xEnd,u16 yEnd)
 * @date       :2018-08-09
 * @function   :Setting LCD display window
 * @parameters :xStar:the bebinning x coordinate of the LCD display window
								yStar:the bebinning y coordinate of the LCD display window
								xEnd:the endning x coordinate of the LCD display window
								yEnd:the endning y coordinate of the LCD display window
 * @retvalue   :None
******************************************************************************/
void LCD_SetWindows(u16 xStar, u16 yStar,u16 xEnd,u16 yEnd)
{
	LCD_WR_REG(lcddev.setxcmd);LCD_WR_DATA(xStar>>8);
	LCD_WR_REG(lcddev.setxcmd+1);LCD_WR_DATA(xStar&0XFF);
	LCD_WR_REG(lcddev.setxcmd+2);LCD_WR_DATA(xEnd>>8);
	LCD_WR_REG(lcddev.setxcmd+3);LCD_WR_DATA(xEnd&0XFF);
	LCD_WR_REG(lcddev.setycmd);LCD_WR_DATA(yStar>>8);
	LCD_WR_REG(lcddev.setycmd+1);LCD_WR_DATA(yStar&0XFF);
	LCD_WR_REG(lcddev.setycmd+2);LCD_WR_DATA(yEnd>>8);
	LCD_WR_REG(lcddev.setycmd+3);LCD_WR_DATA(yEnd&0XFF);

	LCD_WriteRAM_Prepare();	//¿ªÊ¼Ð´ÈëGRAM
}

/*****************************************************************************
 * @name       :void LCD_SetCursor(u16 Xpos, u16 Ypos)
 * @date       :2018-08-09
 * @function   :Set coordinate value
 * @parameters :Xpos:the  x coordinate of the pixel
								Ypos:the  y coordinate of the pixel
 * @retvalue   :None
******************************************************************************/
void LCD_SetCursor(u16 Xpos, u16 Ypos)
{
	LCD_SetWindows(Xpos,Ypos,Xpos,Ypos);
}
/*****************************************************************************
 * @name       :void LCD_Clear(u16 Color)
 * @date       :2018-08-09
 * @function   :Full screen filled LCD screen
 * @parameters :color:Filled color
 * @retvalue   :None
******************************************************************************/
void LCD_init()
{
	//FMC_BANK1_WriteReg(LCD_READ_ID4);
	make_ttab();
	LCD_WR_REG(LCD_READ_ID4<<8);
	printf("readId4 %x %x \r\n",FMC_BANK1_ReadData(),FMC_BANK1_ReadData());

	//FMC_BANK1_WriteReg(LCD_READ_ID1);
	//FMC_BANK1_WriteReg
	LCD_WR_REG(LCD_READ_ID1<<8);
	FMC_BANK1_ReadData();
	printf("readId1(%X) %02x \r\n",LCD_READ_ID1,FMC_BANK1_ReadData());
	//FMC_BANK1_WriteReg(LCD_READ_ID2);
	LCD_WR_REG(LCD_READ_ID2<<8);
	FMC_BANK1_ReadData();
	printf("readId2(%X) %02x \r\n",LCD_READ_ID2,FMC_BANK1_ReadData());
	//FMC_BANK1_WriteReg(LCD_READ_ID3);
	LCD_WR_REG(LCD_READ_ID3<<8);
	FMC_BANK1_ReadData();
	printf("readId3(%X) %02x \r\n",LCD_READ_ID3,FMC_BANK1_ReadData());
	//LCD_WR_REG(LCD_READ_ID4<<8);
	//printf("readId4 %x %x \r\n",FMC_BANK1_ReadData(),FMC_BANK1_ReadData());

	LCD_SINIT();
	LCD_WR_REG(LCD_READ_ID4<<8);
	printf("readId4 %x %x %x %x \r\n",FMC_BANK1_ReadData(),FMC_BANK1_ReadData(),FMC_BANK1_ReadData(),FMC_BANK1_ReadData());
	//LCD_Read_ID4();


//	ili9341_Init();

}

#include "fonts.h"
#include "5x5_font.h"
#if 0
void LCD_Draw_Char(char Character, int16_t X, int16_t Y, uint16_t Colour, uint16_t Size, uint16_t Background_Colour)
{
	//~ flagReinit = 1;
		uint8_t 	function_char;
    int16_t 	i,j;

	function_char = Character;

        if (function_char < 0x20)
	{
		Character = 0;
	}
	else
	{
		function_char -= 32;
	}

	char temp[CHAR_WIDTH];
	uint8_t k;
	for( k = 0; k<CHAR_WIDTH; k++)
	{
		temp[k] = font[function_char*CHAR_WIDTH+k];
	}

    // Draw pixels
		LCD_fillRect2(X, Y, CHAR_WIDTH*Size, CHAR_HEIGHT*Size, Background_Colour);
    for (j=0; j<CHAR_WIDTH; j++) {
        for (i=0; i<CHAR_HEIGHT; i++) {
            if (temp[i] & (1<<(CHAR_WIDTH-1-j))) {
								//~ LCD_fillRect(X+(j*Size), Y+(i*Size), Size,Size, Colour);
							LCD_fillRect2(X+(j*Size), Y+(i*Size), Size,Size, Colour);
            }
        }
    }
}
void LCD_Draw_Char2(char Character, int16_t X, int16_t Y, uint16_t Colour, uint16_t SizeX,uint16_t SizeY, uint16_t Background_Colour)
{
	//~ flagReinit = 1;
		uint8_t 	function_char;
    int16_t 	i,j;

	function_char = Character;

        if (function_char < 0x20)
	{
		Character = 0;
	}
	else
	{
		function_char -= 32;
	}

	char temp[CHAR_WIDTH];
	uint8_t k;
	for( k = 0; k<CHAR_WIDTH; k++)
	{
		temp[k] = font[function_char*CHAR_WIDTH+k];
	}

    // Draw pixels
		LCD_fillRect2(X, Y, CHAR_WIDTH*SizeX, CHAR_HEIGHT*SizeY, Background_Colour);
    for (j=0; j<CHAR_WIDTH; j++) {
        for (i=0; i<CHAR_HEIGHT; i++) {
            if (temp[i] & (1<<(CHAR_WIDTH-1-j))) {
								//~ LCD_fillRect(X+(j*Size), Y+(i*Size), Size,Size, Colour);
							LCD_fillRect2(X+(j*SizeX), Y+(i*SizeY), SizeX,SizeY, Colour);
            }
        }
    }
}
#endif
/*Draws an array of characters (fonts imported from fonts.h) at X,Y location with specified font colour, size and Background colour*/
/*See fonts.h implementation of font on what is required for changing to a different font when switching fonts libraries*/
void  LCD_Draw_Text(const char* Text, int16_t X, int16_t Y, uint16_t Colour, uint16_t Size, uint16_t Background_Colour)
{
    while (*Text) {
        LCD_Draw_Char(*Text, X, Y, Colour, Size, Background_Colour);
        X += CHAR_WIDTH*Size;
	Text++;
    }
}
void LCD_Draw_Char2(char Character, int16_t X, int16_t Y, uint16_t Colour, uint16_t SizeX,uint16_t SizeY, uint16_t Background_Colour);

void  LCD_Draw_Text2(const char* Text, int16_t X, int16_t Y, uint16_t Colour, uint16_t SizeX, uint16_t SizeY,uint16_t Background_Colour)
{
    while (*Text) {
        LCD_Draw_Char2(*Text, X, Y, Colour, SizeX,SizeY, Background_Colour);
        X += CHAR_WIDTH*SizeX;
	Text++;
    }
}


#if 0
#define COLOR_3BYTES 1
/** @addtogroup BSP
  * @{
  */ 

/** @addtogroup Components
  * @{
  */ 
  
/** @addtogroup ILI9341
  * @brief This file provides a set of functions needed to drive the 
  *        ILI9341 LCD.
  * @{
  */

/** @defgroup ILI9341_Private_TypesDefinitions
  * @{
  */ 
/**
  * @}
  */ 

/** @defgroup ILI9341_Private_Defines
  * @{
  */
/**
  * @}
  */ 
  
/** @defgroup ILI9341_Private_Macros
  * @{
  */
/**
  * @}
  */  

/** @defgroup ILI9341_Private_Variables
  * @{
  */ 

LCD_DrvTypeDef   ili9341_drv = 
{
  ili9341_Init,
  ili9341_ReadID,
  ili9341_DisplayOn,
  ili9341_DisplayOff,
  0,
  0,
  0,
  0,
  0,
  0,
  ili9341_GetLcdPixelWidth,
  ili9341_GetLcdPixelHeight,
  0,
  0,    
};

/**
  * @}
  */ 
  
/** @defgroup ILI9341_Private_FunctionPrototypes
  * @{
  */

/**
  * @}
  */ 
  
/** @defgroup ILI9341_Private_Functions
  * @{
  */   

/**
  * @brief  Power on the LCD.
  * @param  None
  * @retval None
  */
  
 static const uint8_t init_commands[] = {
        // Power control A
        6, LCD_POWERA, 0x39, 0x2C, 0x00, 0x34, 0x02,
        // Power control B
        4, LCD_POWERB, 0x00, 0xC1, 0x30,
        // Driver timing control A
        4, LCD_DTCA, 0x85, 0x00, 0x78,
        // Driver timing control B
        3, LCD_DTCB, 0x00, 0x00,
        // Power on sequence control
        5, LCD_POWER_SEQ, 0x64, 0x03, 0x12, 0x81,
        // Pump ratio control
        2, LCD_PRC, 0x20,
        // Power control 1
        2, LCD_POWER1, 0x10,
        // Power control 2
        2, LCD_POWER2, 0x10,
        // VCOM control 1
        3, LCD_VCOM1, 0x3E, 0x28,
        // VCOM cotnrol 2
        2, LCD_VCOM2, 0x86,
        // Memory access control
        2, LCD_MAC, 0x48,
	//~ 2, LCD_MAC, 0xC8,
        // Pixel format set
#ifdef COLOR_3BYTES
	2, LCD_PIXEL_FORMAT, 0x66,
#else
        2, LCD_PIXEL_FORMAT, 0x55,
#endif	
        // Frame rate control
        //3, LCD_FRMCTR1, 0x00, 0x1B,
	3, LCD_FRMCTR1, 0x00, 50,
        // Display function control
        4, LCD_DFC, 0x08, 0x82, 0x27,
        // 3Gamma function disable
        2, LCD_3GAMMA_EN, 0x00,
        // Gamma curve selected
        2, LCD_GAMMA, 0x01,
        // Set positive gamma
        16, LCD_PGAMMA, 0x0F, 0x31, 0x2B, 0x0C, 0x0E, 0x08, 0x4E, 0xF1, 0x37, 0x07, 0x10, 0x03, 0x0E, 0x09, 0x00,
        16, LCD_NGAMMA, 0x00, 0x0E, 0x14, 0x03, 0x11, 0x07, 0x31, 0xC1, 0x48, 0x08, 0x0F, 0x0C, 0x31, 0x36, 0x0F,
        0
};
void  dmaSendDataCont8(uint8_t *data,int cnt)
{
	int k ;
	for( k=0;k<cnt;k++)
	{
		ili9341_WriteData(data[k]);
	}
}
void LCD_exitStandby() {
    ili9341_WriteReg(LCD_SLEEP_OUT);
    Delay(150);
    ili9341_WriteReg(LCD_DISPLAY_ON);
}

void ili9341_Init(void)
{
  /* Initialize ILI9341 low level bus layer ----------------------------------*/
  //~ LCD_IO_Init();
#if 0	
  ili9341_WriteReg(0xCA);
  ili9341_WriteData(0xC3);
  ili9341_WriteData(0x08);
  ili9341_WriteData(0x50);
  ili9341_WriteReg(LCD_POWERB);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0xC1);
  ili9341_WriteData(0x30);
  ili9341_WriteReg(LCD_POWER_SEQ);
  ili9341_WriteData(0x64);
  ili9341_WriteData(0x03);
  ili9341_WriteData(0x12);
  ili9341_WriteData(0x81);
  ili9341_WriteReg(LCD_DTCA);
  ili9341_WriteData(0x85);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0x78);
  ili9341_WriteReg(LCD_POWERA);
  ili9341_WriteData(0x39);
  ili9341_WriteData(0x2C);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0x34);
  ili9341_WriteData(0x02);
  ili9341_WriteReg(LCD_PRC);
  ili9341_WriteData(0x20);
  ili9341_WriteReg(LCD_DTCB);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0x00);
  ili9341_WriteReg(LCD_FRMCTR1);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0x1B);
  ili9341_WriteReg(LCD_DFC);
  ili9341_WriteData(0x0A);
  ili9341_WriteData(0xA2);
  ili9341_WriteReg(LCD_POWER1);
  ili9341_WriteData(0x10);
  ili9341_WriteReg(LCD_POWER2);
  ili9341_WriteData(0x10);
  ili9341_WriteReg(LCD_VCOM1);
  ili9341_WriteData(0x45);
  ili9341_WriteData(0x15);
  ili9341_WriteReg(LCD_VCOM2);
  ili9341_WriteData(0x90);
  ili9341_WriteReg(LCD_MAC);
  ili9341_WriteData(0xC8);
  ili9341_WriteReg(LCD_3GAMMA_EN);
  ili9341_WriteData(0x00);
  ili9341_WriteReg(LCD_RGB_INTERFACE);
  ili9341_WriteData(0xC2);
  ili9341_WriteReg(LCD_DFC);
  ili9341_WriteData(0x0A);
  ili9341_WriteData(0xA7);
  ili9341_WriteData(0x27);
  ili9341_WriteData(0x04);
  
  /* Colomn address set */
  ili9341_WriteReg(LCD_COLUMN_ADDR);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0xEF);
  /* Page address set */
  ili9341_WriteReg(LCD_PAGE_ADDR);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0x01);
  ili9341_WriteData(0x3F);
  ili9341_WriteReg(LCD_INTERFACE);
  ili9341_WriteData(0x01);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0x06);
  
  ili9341_WriteReg(LCD_GRAM);
  LCD_Delay(200);
  
  ili9341_WriteReg(LCD_GAMMA);
  ili9341_WriteData(0x01);
  
  ili9341_WriteReg(LCD_PGAMMA);
  ili9341_WriteData(0x0F);
  ili9341_WriteData(0x29);
  ili9341_WriteData(0x24);
  ili9341_WriteData(0x0C);
  ili9341_WriteData(0x0E);
  ili9341_WriteData(0x09);
  ili9341_WriteData(0x4E);
  ili9341_WriteData(0x78);
  ili9341_WriteData(0x3C);
  ili9341_WriteData(0x09);
  ili9341_WriteData(0x13);
  ili9341_WriteData(0x05);
  ili9341_WriteData(0x17);
  ili9341_WriteData(0x11);
  ili9341_WriteData(0x00);
  ili9341_WriteReg(LCD_NGAMMA);
  ili9341_WriteData(0x00);
  ili9341_WriteData(0x16);
  ili9341_WriteData(0x1B);
  ili9341_WriteData(0x04);
  ili9341_WriteData(0x11);
  ili9341_WriteData(0x07);
  ili9341_WriteData(0x31);
  ili9341_WriteData(0x33);
  ili9341_WriteData(0x42);
  ili9341_WriteData(0x05);
  ili9341_WriteData(0x0C);
  ili9341_WriteData(0x0A);
  ili9341_WriteData(0x28);
  ili9341_WriteData(0x2F);
  ili9341_WriteData(0x0F);
  ili9341_WriteReg(LCD_PIXEL_FORMAT);
  ili9341_WriteData(0x66);
  
  ili9341_WriteReg(LCD_SLEEP_OUT);
  LCD_Delay(200);
  ili9341_WriteReg(LCD_DISPLAY_ON);
  /* GRAM start writing */
  ili9341_WriteReg(LCD_GRAM);
#endif
//~ LCD_exitStandby();
//~ /*
    uint8_t count;
    uint8_t *address = (uint8_t *) init_commands;
    //~ SPI_MASTER->CR1 &= ~SPI_CR1_SPE; // DISABLE SPI
    //~ SPI_MASTER->CR1 &= ~SPI_CR1_DFF; // SPI 8
    //~ SPI_MASTER->CR1 |= SPI_CR1_SPE;  // ENABLE SPI

    //~ TFT_CS_RESET;
    while (1) {
        count = *(address++);
        if (count-- == 0) break;
        ili9341_WriteReg(*(address++));
        dmaSendDataCont8(address, count);
	    //~ TFT_CS_SET;
        address += count;
    }
    //~ */
#if 0
    
  /* Configure LCD */
  #endif
}

/**
  * @brief  Disables the Display.
  * @param  None
  * @retval LCD Register Value.
  */
uint16_t ili9341_ReadID(void)
{
  //~ LCD_IO_Init();
  return ((uint16_t)ili9341_ReadData(LCD_READ_ID4, LCD_READ_ID4_SIZE));
}

/**
  * @brief  Enables the Display.
  * @param  None
  * @retval None
  */
void ili9341_DisplayOn(void)
{
  /* Display On */
  ili9341_WriteReg(LCD_DISPLAY_ON);
}

/**
  * @brief  Disables the Display.
  * @param  None
  * @retval None
  */
void ili9341_DisplayOff(void)
{
  /* Display Off */
  ili9341_WriteReg(LCD_DISPLAY_OFF);
}

/**
  * @brief  Writes  to the selected LCD register.
  * @param  LCD_Reg: address of the selected register.
  * @retval None
  */

/**
  * @brief  Reads the selected LCD Register.
  * @param  RegValue: Address of the register to read
  * @param  ReadSize: Number of bytes to read
  * @retval LCD Register Value.
  */
#ifdef    COLOR_3BYTES
inline void color_convert(uint16_t color,uint8_t* result)
{
	//~ #define RED             0xF800 
	//~ #define BLUE            0x001F
	//~ #define GREEN           0x07E0  
	result[2]=  ((color&0x1f)		<<(1+2))<<1;//|0x80;    //5 bit BLUE
	result[1]=  (((color>>5)&0x3f) <<(0+1))<<1;//|0x80;    //6 bit GREEN 
	result[0]=  (((color>>11)&0x1f)<<(1+2))<<1;//|0x80;    //5 bit  //RED
}
#endif



/**
  * @brief  Get LCD PIXEL WIDTH.
  * @param  None
  * @retval LCD PIXEL WIDTH.
  */
uint16_t ili9341_GetLcdPixelWidth(void)
{
  /* Return LCD PIXEL WIDTH */
  return ILI9341_LCD_PIXEL_WIDTH;
}

/**
  * @brief  Get LCD PIXEL HEIGHT.
  * @param  None
  * @retval LCD PIXEL HEIGHT.
  */
uint16_t ili9341_GetLcdPixelHeight(void)
{
  /* Return LCD PIXEL HEIGHT */
  return ILI9341_LCD_PIXEL_HEIGHT;
}


inline  void dmaSendDataCont16(uint16_t *data, uint32_t n) 
{
    int k;
    uint8_t dummy;
    uint8_t *pdata = (uint8_t *)data;
    for( k=0;k<n;k++)
    {
	    ili9341_WriteData(*(pdata+1));
	    ili9341_WriteData(*(pdata));
	    pdata+=2;
    }	    
}


void LCD_setAddressWindow(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2) {
    uint16_t pointData[2];

    //~ TFT_CS_RESET;
    LCD_IO_WriteReg(LCD_COLUMN_ADDR);
    pointData[0] = x1;
    pointData[1] = x2;
    dmaSendDataCont16(pointData, 2);

    LCD_IO_WriteReg(LCD_PAGE_ADDR);
    pointData[0] = y1;
    pointData[1] = y2;
    dmaSendDataCont16(pointData, 2);
}


inline  void dmaFill16(uint16_t color, uint32_t n) {
    //~ TFT_CS_RESET;
    uint8_t dummy;
    LCD_IO_WriteReg(LCD_GRAM);
#ifdef    COLOR_3BYTES
     uint8_t pdata[3];
    color_convert(color,pdata);
    while (n != 0) 
    {
	dmaSendDataCont8(pdata,3);
	n--;    
    }
#else	
    uint8_t *pdata = (uint8_t *)&color;
    while (n != 0) 
       {
        dmaSendDataCont8(pdata,2);
	n--;    
    }
#endif	
}


void LCD_FullRect3(uint16_t x1, uint16_t y1,uint8_t * adress,uint16_t w,uint16_t h) 
{
        LCD_setAddressWindow(x1, y1, (uint16_t) (x1+w-1), (uint16_t) (y1+h-1));
    //~ LCD_setSpi16();
        uint8_t dummy;
       LCD_IO_WriteReg(LCD_GRAM);
#ifdef    COLOR_3BYTES
	int k;
	for(k=w*h;k>0;k--)
	{
		ili9341_WriteData(adress[0]);
		ili9341_WriteData(adress[1]);
		ili9341_WriteData(adress[2]);
		//~ adress+=3;
	}
#else	
#endif    
}


void LCD_fillRect(uint16_t x1, uint16_t y1, uint16_t w, uint16_t h, uint16_t color) {
     uint8_t pdata[3];
     color_convert(color,pdata);
     LCD_FullRect3(x1,y1,pdata,w,h); 
}


/**
  * @}
  */ 

/**
  * @}
  */ 
  
/**
  * @}
  */ 

/**
  * @}
  */
  
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
#endif
